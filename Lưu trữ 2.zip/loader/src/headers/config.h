#pragma once

#define HTTP_SERVER "18.140.51.138"
#define HTTP_PORT 80

#define TFTP_SERVER "18.140.51.138"
